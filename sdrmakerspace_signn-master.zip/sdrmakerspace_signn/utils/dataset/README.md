This set of scripts aim to build the SIGNN_2019_01 dataset.
The scripts are forked from the [RadioML repository](https://github.com/radioML/dataset) provided by DeepSig Inc. and edited to satisfy the needs of the signn project.

#### Changelog
  
* Add white Gaussian noise transmitter
* Export dataset in HDF5 format
* Generate the classes.txt
