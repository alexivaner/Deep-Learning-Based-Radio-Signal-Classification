from .deepsigcnn import deepsigcnn
from .deepsigvgg import deepsigvgg
from .deepsigresnet import deepsigresnet